﻿namespace _1751012086_TrinhHoangYen
{
    partial class fBangDieuKhien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fBangDieuKhien));
            this.pnlNutBam = new System.Windows.Forms.Panel();
            this.btXoaTaiKhoan = new System.Windows.Forms.Button();
            this.btXemTaiKhoan = new System.Windows.Forms.Button();
            this.btThemTaiKhoan = new System.Windows.Forms.Button();
            this.btSuaTaiKhoan = new System.Windows.Forms.Button();
            this.dtgvTaiKhoan = new System.Windows.Forms.DataGridView();
            this.btDatLaiMK = new System.Windows.Forms.Button();
            this.panel51 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.txtTenDangNhap = new System.Windows.Forms.TextBox();
            this.tpDangKy = new System.Windows.Forms.TabPage();
            this.dtgvDangKy = new System.Windows.Forms.DataGridView();
            this.tpSinhVien = new System.Windows.Forms.TabPage();
            this.dtgvSinhVien = new System.Windows.Forms.DataGridView();
            this.tpMonHoc = new System.Windows.Forms.TabPage();
            this.dtgvMonHoc = new System.Windows.Forms.DataGridView();
            this.tpGiangVien = new System.Windows.Forms.TabPage();
            this.dtgvGiangVien = new System.Windows.Forms.DataGridView();
            this.tpLop = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btSuaLop = new System.Windows.Forms.Button();
            this.panel38 = new System.Windows.Forms.Panel();
            this.txtKhoaHoc = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtKhoa_Lop = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btThemLop = new System.Windows.Forms.Button();
            this.btXoaLop = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txtTenLop = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dtgvLop = new System.Windows.Forms.DataGridView();
            this.panel8 = new System.Windows.Forms.Panel();
            this.cbLop_Khoa = new System.Windows.Forms.ComboBox();
            this.txtTimLop = new System.Windows.Forms.TextBox();
            this.btTimLop = new System.Windows.Forms.Button();
            this.tpKhoa = new System.Windows.Forms.TabPage();
            this.dtgvKhoa = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtTimKhoa = new System.Windows.Forms.TextBox();
            this.btTimKhoa = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btSuaKhoa = new System.Windows.Forms.Button();
            this.panel37 = new System.Windows.Forms.Panel();
            this.txtNamThanhLap = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btThemKhoa = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtTenKhoa = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btXoaKhoa = new System.Windows.Forms.Button();
            this.pnlTenDangNhap = new System.Windows.Forms.Panel();
            this.txtMaKhoa = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tcAdmin = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).BeginInit();
            this.tpDangKy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDangKy)).BeginInit();
            this.tpSinhVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvSinhVien)).BeginInit();
            this.tpMonHoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvMonHoc)).BeginInit();
            this.tpGiangVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvGiangVien)).BeginInit();
            this.tpLop.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvLop)).BeginInit();
            this.panel8.SuspendLayout();
            this.tpKhoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKhoa)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel13.SuspendLayout();
            this.pnlTenDangNhap.SuspendLayout();
            this.tcAdmin.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlNutBam
            // 
            this.pnlNutBam.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlNutBam.Location = new System.Drawing.Point(3, 3);
            this.pnlNutBam.Name = "pnlNutBam";
            this.pnlNutBam.Size = new System.Drawing.Size(467, 50);
            this.pnlNutBam.TabIndex = 3;
            // 
            // btXoaTaiKhoan
            // 
            this.btXoaTaiKhoan.BackColor = System.Drawing.Color.Black;
            this.btXoaTaiKhoan.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btXoaTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btXoaTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btXoaTaiKhoan.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaTaiKhoan.ForeColor = System.Drawing.Color.White;
            this.btXoaTaiKhoan.Location = new System.Drawing.Point(121, 5);
            this.btXoaTaiKhoan.Name = "btXoaTaiKhoan";
            this.btXoaTaiKhoan.Size = new System.Drawing.Size(110, 40);
            this.btXoaTaiKhoan.TabIndex = 5;
            this.btXoaTaiKhoan.Text = "Xóa";
            this.btXoaTaiKhoan.UseVisualStyleBackColor = false;
            // 
            // btXemTaiKhoan
            // 
            this.btXemTaiKhoan.BackColor = System.Drawing.Color.Black;
            this.btXemTaiKhoan.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btXemTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btXemTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btXemTaiKhoan.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXemTaiKhoan.ForeColor = System.Drawing.Color.White;
            this.btXemTaiKhoan.Location = new System.Drawing.Point(353, 5);
            this.btXemTaiKhoan.Name = "btXemTaiKhoan";
            this.btXemTaiKhoan.Size = new System.Drawing.Size(110, 40);
            this.btXemTaiKhoan.TabIndex = 5;
            this.btXemTaiKhoan.Text = "Xem";
            this.btXemTaiKhoan.UseVisualStyleBackColor = false;
            // 
            // btThemTaiKhoan
            // 
            this.btThemTaiKhoan.BackColor = System.Drawing.Color.White;
            this.btThemTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btThemTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btThemTaiKhoan.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemTaiKhoan.ForeColor = System.Drawing.Color.Black;
            this.btThemTaiKhoan.Location = new System.Drawing.Point(5, 5);
            this.btThemTaiKhoan.Name = "btThemTaiKhoan";
            this.btThemTaiKhoan.Size = new System.Drawing.Size(110, 40);
            this.btThemTaiKhoan.TabIndex = 4;
            this.btThemTaiKhoan.Text = "Thêm";
            this.btThemTaiKhoan.UseVisualStyleBackColor = false;
            // 
            // btSuaTaiKhoan
            // 
            this.btSuaTaiKhoan.BackColor = System.Drawing.Color.White;
            this.btSuaTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btSuaTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btSuaTaiKhoan.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSuaTaiKhoan.ForeColor = System.Drawing.Color.Black;
            this.btSuaTaiKhoan.Location = new System.Drawing.Point(237, 5);
            this.btSuaTaiKhoan.Name = "btSuaTaiKhoan";
            this.btSuaTaiKhoan.Size = new System.Drawing.Size(110, 40);
            this.btSuaTaiKhoan.TabIndex = 4;
            this.btSuaTaiKhoan.Text = "Sửa";
            this.btSuaTaiKhoan.UseVisualStyleBackColor = false;
            // 
            // dtgvTaiKhoan
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTaiKhoan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvTaiKhoan.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvTaiKhoan.Location = new System.Drawing.Point(3, 54);
            this.dtgvTaiKhoan.Name = "dtgvTaiKhoan";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTaiKhoan.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvTaiKhoan.Size = new System.Drawing.Size(467, 400);
            this.dtgvTaiKhoan.TabIndex = 0;
            // 
            // btDatLaiMK
            // 
            this.btDatLaiMK.BackColor = System.Drawing.Color.Black;
            this.btDatLaiMK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btDatLaiMK.FlatAppearance.BorderSize = 0;
            this.btDatLaiMK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btDatLaiMK.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDatLaiMK.ForeColor = System.Drawing.Color.White;
            this.btDatLaiMK.Location = new System.Drawing.Point(199, 337);
            this.btDatLaiMK.Name = "btDatLaiMK";
            this.btDatLaiMK.Size = new System.Drawing.Size(110, 40);
            this.btDatLaiMK.TabIndex = 6;
            this.btDatLaiMK.Text = "Đặt lại mật khẩu";
            this.btDatLaiMK.UseVisualStyleBackColor = false;
            // 
            // panel51
            // 
            this.panel51.Location = new System.Drawing.Point(3, 3);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(306, 40);
            this.panel51.TabIndex = 7;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(3, 8);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(143, 21);
            this.label30.TabIndex = 0;
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDangNhap.Location = new System.Drawing.Point(152, 7);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.ReadOnly = true;
            this.txtTenDangNhap.Size = new System.Drawing.Size(151, 26);
            this.txtTenDangNhap.TabIndex = 0;
            // 
            // tpDangKy
            // 
            this.tpDangKy.Controls.Add(this.dtgvDangKy);
            this.tpDangKy.Location = new System.Drawing.Point(4, 30);
            this.tpDangKy.Name = "tpDangKy";
            this.tpDangKy.Padding = new System.Windows.Forms.Padding(3);
            this.tpDangKy.Size = new System.Drawing.Size(860, 461);
            this.tpDangKy.TabIndex = 5;
            this.tpDangKy.Text = "Đăng ký";
            this.tpDangKy.UseVisualStyleBackColor = true;
            // 
            // dtgvDangKy
            // 
            this.dtgvDangKy.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvDangKy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDangKy.Location = new System.Drawing.Point(6, 7);
            this.dtgvDangKy.Name = "dtgvDangKy";
            this.dtgvDangKy.Size = new System.Drawing.Size(848, 451);
            this.dtgvDangKy.TabIndex = 0;
            // 
            // tpSinhVien
            // 
            this.tpSinhVien.Controls.Add(this.dtgvSinhVien);
            this.tpSinhVien.Location = new System.Drawing.Point(4, 30);
            this.tpSinhVien.Name = "tpSinhVien";
            this.tpSinhVien.Padding = new System.Windows.Forms.Padding(3);
            this.tpSinhVien.Size = new System.Drawing.Size(860, 461);
            this.tpSinhVien.TabIndex = 4;
            this.tpSinhVien.Text = "Sinh viên";
            this.tpSinhVien.UseVisualStyleBackColor = true;
            // 
            // dtgvSinhVien
            // 
            this.dtgvSinhVien.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvSinhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvSinhVien.Location = new System.Drawing.Point(3, 6);
            this.dtgvSinhVien.Name = "dtgvSinhVien";
            this.dtgvSinhVien.Size = new System.Drawing.Size(854, 452);
            this.dtgvSinhVien.TabIndex = 1;
            // 
            // tpMonHoc
            // 
            this.tpMonHoc.Controls.Add(this.dtgvMonHoc);
            this.tpMonHoc.Location = new System.Drawing.Point(4, 30);
            this.tpMonHoc.Name = "tpMonHoc";
            this.tpMonHoc.Padding = new System.Windows.Forms.Padding(3);
            this.tpMonHoc.Size = new System.Drawing.Size(860, 461);
            this.tpMonHoc.TabIndex = 3;
            this.tpMonHoc.Text = "Môn học";
            this.tpMonHoc.UseVisualStyleBackColor = true;
            // 
            // dtgvMonHoc
            // 
            this.dtgvMonHoc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvMonHoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvMonHoc.Location = new System.Drawing.Point(6, 6);
            this.dtgvMonHoc.Name = "dtgvMonHoc";
            this.dtgvMonHoc.Size = new System.Drawing.Size(848, 452);
            this.dtgvMonHoc.TabIndex = 1;
            // 
            // tpGiangVien
            // 
            this.tpGiangVien.Controls.Add(this.dtgvGiangVien);
            this.tpGiangVien.Location = new System.Drawing.Point(4, 30);
            this.tpGiangVien.Name = "tpGiangVien";
            this.tpGiangVien.Padding = new System.Windows.Forms.Padding(3);
            this.tpGiangVien.Size = new System.Drawing.Size(860, 461);
            this.tpGiangVien.TabIndex = 2;
            this.tpGiangVien.Text = "Giảng viên";
            this.tpGiangVien.UseVisualStyleBackColor = true;
            // 
            // dtgvGiangVien
            // 
            this.dtgvGiangVien.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvGiangVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvGiangVien.Location = new System.Drawing.Point(6, 6);
            this.dtgvGiangVien.Name = "dtgvGiangVien";
            this.dtgvGiangVien.Size = new System.Drawing.Size(848, 452);
            this.dtgvGiangVien.TabIndex = 1;
            // 
            // tpLop
            // 
            this.tpLop.Controls.Add(this.panel6);
            this.tpLop.Controls.Add(this.panel7);
            this.tpLop.Location = new System.Drawing.Point(4, 30);
            this.tpLop.Name = "tpLop";
            this.tpLop.Padding = new System.Windows.Forms.Padding(3);
            this.tpLop.Size = new System.Drawing.Size(860, 461);
            this.tpLop.TabIndex = 1;
            this.tpLop.Text = "Lớp";
            this.tpLop.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btSuaLop);
            this.panel6.Controls.Add(this.panel38);
            this.panel6.Controls.Add(this.panel17);
            this.panel6.Controls.Add(this.btThemLop);
            this.panel6.Controls.Add(this.btXoaLop);
            this.panel6.Controls.Add(this.panel15);
            this.panel6.Controls.Add(this.panel16);
            this.panel6.Location = new System.Drawing.Point(583, 99);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(274, 358);
            this.panel6.TabIndex = 0;
            // 
            // btSuaLop
            // 
            this.btSuaLop.BackColor = System.Drawing.Color.Black;
            this.btSuaLop.FlatAppearance.BorderSize = 0;
            this.btSuaLop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btSuaLop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSuaLop.ForeColor = System.Drawing.Color.White;
            this.btSuaLop.Location = new System.Drawing.Point(140, 293);
            this.btSuaLop.Name = "btSuaLop";
            this.btSuaLop.Size = new System.Drawing.Size(110, 40);
            this.btSuaLop.TabIndex = 6;
            this.btSuaLop.Text = "Sửa";
            this.btSuaLop.UseVisualStyleBackColor = false;
            this.btSuaLop.Click += new System.EventHandler(this.btSuaLop_Click);
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.txtKhoaHoc);
            this.panel38.Controls.Add(this.label21);
            this.panel38.Location = new System.Drawing.Point(12, 155);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(250, 40);
            this.panel38.TabIndex = 3;
            // 
            // txtKhoaHoc
            // 
            this.txtKhoaHoc.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhoaHoc.Location = new System.Drawing.Point(118, 7);
            this.txtKhoaHoc.Name = "txtKhoaHoc";
            this.txtKhoaHoc.Size = new System.Drawing.Size(120, 26);
            this.txtKhoaHoc.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 18);
            this.label21.TabIndex = 0;
            this.label21.Text = "Khóa học:";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.txtKhoa_Lop);
            this.panel17.Controls.Add(this.label5);
            this.panel17.Location = new System.Drawing.Point(12, 109);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(250, 40);
            this.panel17.TabIndex = 2;
            // 
            // txtKhoa_Lop
            // 
            this.txtKhoa_Lop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhoa_Lop.Location = new System.Drawing.Point(118, 7);
            this.txtKhoa_Lop.Name = "txtKhoa_Lop";
            this.txtKhoa_Lop.Size = new System.Drawing.Size(120, 26);
            this.txtKhoa_Lop.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 18);
            this.label5.TabIndex = 0;
            this.label5.Text = "Khoa:";
            // 
            // btThemLop
            // 
            this.btThemLop.BackColor = System.Drawing.Color.Black;
            this.btThemLop.FlatAppearance.BorderSize = 0;
            this.btThemLop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btThemLop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemLop.ForeColor = System.Drawing.Color.White;
            this.btThemLop.Location = new System.Drawing.Point(140, 201);
            this.btThemLop.Name = "btThemLop";
            this.btThemLop.Size = new System.Drawing.Size(110, 40);
            this.btThemLop.TabIndex = 4;
            this.btThemLop.Text = "Thêm";
            this.btThemLop.UseVisualStyleBackColor = false;
            this.btThemLop.Click += new System.EventHandler(this.btThemLop_Click);
            // 
            // btXoaLop
            // 
            this.btXoaLop.BackColor = System.Drawing.Color.White;
            this.btXoaLop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btXoaLop.FlatAppearance.BorderSize = 0;
            this.btXoaLop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btXoaLop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaLop.ForeColor = System.Drawing.Color.Black;
            this.btXoaLop.Location = new System.Drawing.Point(140, 247);
            this.btXoaLop.Name = "btXoaLop";
            this.btXoaLop.Size = new System.Drawing.Size(110, 40);
            this.btXoaLop.TabIndex = 5;
            this.btXoaLop.Text = "Xóa";
            this.btXoaLop.UseVisualStyleBackColor = false;
            this.btXoaLop.Click += new System.EventHandler(this.btXoaLop_Click);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.txtTenLop);
            this.panel15.Controls.Add(this.label3);
            this.panel15.Location = new System.Drawing.Point(12, 63);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(250, 40);
            this.panel15.TabIndex = 1;
            // 
            // txtTenLop
            // 
            this.txtTenLop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenLop.Location = new System.Drawing.Point(118, 7);
            this.txtTenLop.Name = "txtTenLop";
            this.txtTenLop.Size = new System.Drawing.Size(120, 26);
            this.txtTenLop.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tên lớp:";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txtMaLop);
            this.panel16.Controls.Add(this.label4);
            this.panel16.Location = new System.Drawing.Point(12, 17);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(250, 40);
            this.panel16.TabIndex = 0;
            // 
            // txtMaLop
            // 
            this.txtMaLop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaLop.Location = new System.Drawing.Point(118, 7);
            this.txtMaLop.Name = "txtMaLop";
            this.txtMaLop.Size = new System.Drawing.Size(120, 26);
            this.txtMaLop.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 18);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mã lớp:";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.dtgvLop);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(574, 457);
            this.panel7.TabIndex = 2;
            // 
            // dtgvLop
            // 
            this.dtgvLop.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvLop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvLop.Location = new System.Drawing.Point(3, 75);
            this.dtgvLop.Name = "dtgvLop";
            this.dtgvLop.Size = new System.Drawing.Size(568, 378);
            this.dtgvLop.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.cbLop_Khoa);
            this.panel8.Controls.Add(this.txtTimLop);
            this.panel8.Controls.Add(this.btTimLop);
            this.panel8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel8.Location = new System.Drawing.Point(5, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(566, 66);
            this.panel8.TabIndex = 0;
            // 
            // cbLop_Khoa
            // 
            this.cbLop_Khoa.FormattingEnabled = true;
            this.cbLop_Khoa.Location = new System.Drawing.Point(280, 8);
            this.cbLop_Khoa.Name = "cbLop_Khoa";
            this.cbLop_Khoa.Size = new System.Drawing.Size(144, 22);
            this.cbLop_Khoa.TabIndex = 0;
            // 
            // txtTimLop
            // 
            this.txtTimLop.Location = new System.Drawing.Point(280, 36);
            this.txtTimLop.Name = "txtTimLop";
            this.txtTimLop.Size = new System.Drawing.Size(144, 22);
            this.txtTimLop.TabIndex = 1;
            // 
            // btTimLop
            // 
            this.btTimLop.BackColor = System.Drawing.Color.Black;
            this.btTimLop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btTimLop.FlatAppearance.BorderSize = 0;
            this.btTimLop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btTimLop.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimLop.ForeColor = System.Drawing.Color.White;
            this.btTimLop.Location = new System.Drawing.Point(445, 13);
            this.btTimLop.Name = "btTimLop";
            this.btTimLop.Size = new System.Drawing.Size(110, 40);
            this.btTimLop.TabIndex = 2;
            this.btTimLop.Text = "Tìm";
            this.btTimLop.UseVisualStyleBackColor = false;
            this.btTimLop.Click += new System.EventHandler(this.btTimLop_Click);
            // 
            // tpKhoa
            // 
            this.tpKhoa.Controls.Add(this.dtgvKhoa);
            this.tpKhoa.Controls.Add(this.panel11);
            this.tpKhoa.Controls.Add(this.panel9);
            this.tpKhoa.Location = new System.Drawing.Point(4, 30);
            this.tpKhoa.Name = "tpKhoa";
            this.tpKhoa.Padding = new System.Windows.Forms.Padding(3);
            this.tpKhoa.Size = new System.Drawing.Size(860, 461);
            this.tpKhoa.TabIndex = 0;
            this.tpKhoa.Text = "Khoa";
            this.tpKhoa.UseVisualStyleBackColor = true;
            // 
            // dtgvKhoa
            // 
            this.dtgvKhoa.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvKhoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvKhoa.Location = new System.Drawing.Point(6, 78);
            this.dtgvKhoa.Name = "dtgvKhoa";
            this.dtgvKhoa.Size = new System.Drawing.Size(525, 379);
            this.dtgvKhoa.TabIndex = 3;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.txtTimKhoa);
            this.panel11.Controls.Add(this.btTimKhoa);
            this.panel11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel11.Location = new System.Drawing.Point(6, 6);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(525, 66);
            this.panel11.TabIndex = 0;
            // 
            // txtTimKhoa
            // 
            this.txtTimKhoa.Location = new System.Drawing.Point(276, 21);
            this.txtTimKhoa.Name = "txtTimKhoa";
            this.txtTimKhoa.Size = new System.Drawing.Size(120, 22);
            this.txtTimKhoa.TabIndex = 0;
            // 
            // btTimKhoa
            // 
            this.btTimKhoa.BackColor = System.Drawing.Color.Black;
            this.btTimKhoa.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btTimKhoa.FlatAppearance.BorderSize = 0;
            this.btTimKhoa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btTimKhoa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimKhoa.ForeColor = System.Drawing.Color.White;
            this.btTimKhoa.Location = new System.Drawing.Point(402, 13);
            this.btTimKhoa.Name = "btTimKhoa";
            this.btTimKhoa.Size = new System.Drawing.Size(110, 40);
            this.btTimKhoa.TabIndex = 1;
            this.btTimKhoa.Text = "Tìm";
            this.btTimKhoa.UseVisualStyleBackColor = false;
            this.btTimKhoa.Click += new System.EventHandler(this.btTimKhoa_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btSuaKhoa);
            this.panel9.Controls.Add(this.panel37);
            this.panel9.Controls.Add(this.btThemKhoa);
            this.panel9.Controls.Add(this.panel13);
            this.panel9.Controls.Add(this.btXoaKhoa);
            this.panel9.Controls.Add(this.pnlTenDangNhap);
            this.panel9.Location = new System.Drawing.Point(538, 62);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(316, 395);
            this.panel9.TabIndex = 1;
            // 
            // btSuaKhoa
            // 
            this.btSuaKhoa.BackColor = System.Drawing.Color.Black;
            this.btSuaKhoa.FlatAppearance.BorderSize = 0;
            this.btSuaKhoa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btSuaKhoa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSuaKhoa.ForeColor = System.Drawing.Color.White;
            this.btSuaKhoa.Location = new System.Drawing.Point(162, 249);
            this.btSuaKhoa.Name = "btSuaKhoa";
            this.btSuaKhoa.Size = new System.Drawing.Size(110, 40);
            this.btSuaKhoa.TabIndex = 5;
            this.btSuaKhoa.Text = "Sửa";
            this.btSuaKhoa.UseVisualStyleBackColor = false;
            this.btSuaKhoa.Click += new System.EventHandler(this.btSuaKhoa_Click);
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.txtNamThanhLap);
            this.panel37.Controls.Add(this.label20);
            this.panel37.Location = new System.Drawing.Point(2, 111);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(310, 40);
            this.panel37.TabIndex = 2;
            // 
            // txtNamThanhLap
            // 
            this.txtNamThanhLap.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNamThanhLap.Location = new System.Drawing.Point(150, 7);
            this.txtNamThanhLap.Name = "txtNamThanhLap";
            this.txtNamThanhLap.Size = new System.Drawing.Size(155, 26);
            this.txtNamThanhLap.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(3, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(141, 21);
            this.label20.TabIndex = 0;
            this.label20.Text = "Năm thành lập:";
            // 
            // btThemKhoa
            // 
            this.btThemKhoa.BackColor = System.Drawing.Color.Black;
            this.btThemKhoa.FlatAppearance.BorderSize = 0;
            this.btThemKhoa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btThemKhoa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemKhoa.ForeColor = System.Drawing.Color.White;
            this.btThemKhoa.Location = new System.Drawing.Point(162, 157);
            this.btThemKhoa.Name = "btThemKhoa";
            this.btThemKhoa.Size = new System.Drawing.Size(110, 40);
            this.btThemKhoa.TabIndex = 3;
            this.btThemKhoa.Text = "Thêm";
            this.btThemKhoa.UseVisualStyleBackColor = false;
            this.btThemKhoa.Click += new System.EventHandler(this.btThemKhoa_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.txtTenKhoa);
            this.panel13.Controls.Add(this.label2);
            this.panel13.Location = new System.Drawing.Point(2, 65);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(310, 40);
            this.panel13.TabIndex = 1;
            // 
            // txtTenKhoa
            // 
            this.txtTenKhoa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenKhoa.Location = new System.Drawing.Point(150, 7);
            this.txtTenKhoa.Name = "txtTenKhoa";
            this.txtTenKhoa.Size = new System.Drawing.Size(155, 26);
            this.txtTenKhoa.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên khoa:";
            // 
            // btXoaKhoa
            // 
            this.btXoaKhoa.BackColor = System.Drawing.Color.White;
            this.btXoaKhoa.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btXoaKhoa.FlatAppearance.BorderSize = 0;
            this.btXoaKhoa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btXoaKhoa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaKhoa.ForeColor = System.Drawing.Color.Black;
            this.btXoaKhoa.Location = new System.Drawing.Point(162, 203);
            this.btXoaKhoa.Name = "btXoaKhoa";
            this.btXoaKhoa.Size = new System.Drawing.Size(110, 40);
            this.btXoaKhoa.TabIndex = 4;
            this.btXoaKhoa.Text = "Xóa";
            this.btXoaKhoa.UseVisualStyleBackColor = false;
            this.btXoaKhoa.Click += new System.EventHandler(this.btXoaKhoa_Click);
            // 
            // pnlTenDangNhap
            // 
            this.pnlTenDangNhap.Controls.Add(this.txtMaKhoa);
            this.pnlTenDangNhap.Controls.Add(this.label1);
            this.pnlTenDangNhap.Location = new System.Drawing.Point(2, 19);
            this.pnlTenDangNhap.Name = "pnlTenDangNhap";
            this.pnlTenDangNhap.Size = new System.Drawing.Size(310, 40);
            this.pnlTenDangNhap.TabIndex = 0;
            // 
            // txtMaKhoa
            // 
            this.txtMaKhoa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaKhoa.Location = new System.Drawing.Point(150, 7);
            this.txtMaKhoa.Name = "txtMaKhoa";
            this.txtMaKhoa.Size = new System.Drawing.Size(155, 26);
            this.txtMaKhoa.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã khoa:";
            // 
            // tcAdmin
            // 
            this.tcAdmin.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tcAdmin.Controls.Add(this.tpKhoa);
            this.tcAdmin.Controls.Add(this.tpLop);
            this.tcAdmin.Controls.Add(this.tpGiangVien);
            this.tcAdmin.Controls.Add(this.tpMonHoc);
            this.tcAdmin.Controls.Add(this.tpSinhVien);
            this.tcAdmin.Controls.Add(this.tpDangKy);
            this.tcAdmin.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcAdmin.Location = new System.Drawing.Point(8, 8);
            this.tcAdmin.Name = "tcAdmin";
            this.tcAdmin.SelectedIndex = 0;
            this.tcAdmin.Size = new System.Drawing.Size(868, 495);
            this.tcAdmin.TabIndex = 0;
            // 
            // fBangDieuKhien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(884, 511);
            this.Controls.Add(this.tcAdmin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fBangDieuKhien";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bảng điều khiển";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).EndInit();
            this.tpDangKy.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDangKy)).EndInit();
            this.tpSinhVien.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvSinhVien)).EndInit();
            this.tpMonHoc.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvMonHoc)).EndInit();
            this.tpGiangVien.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvGiangVien)).EndInit();
            this.tpLop.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvLop)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tpKhoa.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKhoa)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.pnlTenDangNhap.ResumeLayout(false);
            this.pnlTenDangNhap.PerformLayout();
            this.tcAdmin.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlNutBam;
        private System.Windows.Forms.Button btXoaTaiKhoan;
        private System.Windows.Forms.Button btXemTaiKhoan;
        private System.Windows.Forms.Button btThemTaiKhoan;
        private System.Windows.Forms.Button btSuaTaiKhoan;
        private System.Windows.Forms.DataGridView dtgvTaiKhoan;
        private System.Windows.Forms.Button btDatLaiMK;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.TabPage tpDangKy;
        private System.Windows.Forms.DataGridView dtgvDangKy;
        private System.Windows.Forms.TabPage tpSinhVien;
        private System.Windows.Forms.TabPage tpMonHoc;
        private System.Windows.Forms.TabPage tpGiangVien;
        private System.Windows.Forms.TabPage tpLop;
        private System.Windows.Forms.TextBox txtTimLop;
        private System.Windows.Forms.Button btTimLop;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.TextBox txtKhoaHoc;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txtTenLop;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView dtgvLop;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btSuaLop;
        private System.Windows.Forms.Button btThemLop;
        private System.Windows.Forms.Button btXoaLop;
        private System.Windows.Forms.TabPage tpKhoa;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TextBox txtNamThanhLap;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtTenKhoa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlTenDangNhap;
        private System.Windows.Forms.TextBox txtMaKhoa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btSuaKhoa;
        private System.Windows.Forms.Button btThemKhoa;
        private System.Windows.Forms.Button btXoaKhoa;
        private System.Windows.Forms.TabControl tcAdmin;
        private System.Windows.Forms.TextBox txtKhoa_Lop;
        private System.Windows.Forms.ComboBox cbLop_Khoa;
        private System.Windows.Forms.DataGridView dtgvSinhVien;
        private System.Windows.Forms.DataGridView dtgvMonHoc;
        private System.Windows.Forms.DataGridView dtgvGiangVien;
        private System.Windows.Forms.DataGridView dtgvKhoa;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txtTimKhoa;
        private System.Windows.Forms.Button btTimKhoa;
    }
}