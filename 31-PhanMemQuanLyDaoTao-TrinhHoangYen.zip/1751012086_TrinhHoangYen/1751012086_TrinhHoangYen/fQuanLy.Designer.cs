﻿namespace _1751012086_TrinhHoangYen
{
    partial class fQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fQuanLy));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ttmiDanhMuc = new System.Windows.Forms.ToolStripMenuItem();
            this.ttmiTaiKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.ttmiThongTinTaiKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.ttmiDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.chứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btThoat = new System.Windows.Forms.Button();
            this.btXoaSV_MH = new System.Windows.Forms.Button();
            this.btThemSV_MH = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtTimSV = new System.Windows.Forms.TextBox();
            this.btTimSV = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSdtSV = new System.Windows.Forms.TextBox();
            this.txtHoTenSV = new System.Windows.Forms.TextBox();
            this.txtLopSV = new System.Windows.Forms.TextBox();
            this.txtGioiTinhSV = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSiSo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCBGV = new System.Windows.Forms.TextBox();
            this.txtTenMH = new System.Windows.Forms.TextBox();
            this.txtSoTC = new System.Windows.Forms.TextBox();
            this.lvSinhVien = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel10 = new System.Windows.Forms.Panel();
            this.lvMonHoc = new System.Windows.Forms.ListView();
            this.clMa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clTen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clNgay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clTT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbTimKhoa = new System.Windows.Forms.ComboBox();
            this.btTimMH = new System.Windows.Forms.Button();
            this.txtTimMH = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ttmiDanhMuc,
            this.ttmiTaiKhoan,
            this.chứcNăngToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(984, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ttmiDanhMuc
            // 
            this.ttmiDanhMuc.Name = "ttmiDanhMuc";
            this.ttmiDanhMuc.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.ttmiDanhMuc.Size = new System.Drawing.Size(140, 25);
            this.ttmiDanhMuc.Text = "Bảng điều khiển";
            this.ttmiDanhMuc.Click += new System.EventHandler(this.ttmiABangDieuKhien_Click);
            // 
            // ttmiTaiKhoan
            // 
            this.ttmiTaiKhoan.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ttmiThongTinTaiKhoan,
            this.ttmiDangXuat});
            this.ttmiTaiKhoan.Name = "ttmiTaiKhoan";
            this.ttmiTaiKhoan.Size = new System.Drawing.Size(94, 25);
            this.ttmiTaiKhoan.Text = "Tài khoản";
            // 
            // ttmiThongTinTaiKhoan
            // 
            this.ttmiThongTinTaiKhoan.Name = "ttmiThongTinTaiKhoan";
            this.ttmiThongTinTaiKhoan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.ttmiThongTinTaiKhoan.Size = new System.Drawing.Size(282, 26);
            this.ttmiThongTinTaiKhoan.Text = "Thông tin tài khoản";
            this.ttmiThongTinTaiKhoan.Click += new System.EventHandler(this.ttmiThongTinTaiKhoan_Click);
            // 
            // ttmiDangXuat
            // 
            this.ttmiDangXuat.Name = "ttmiDangXuat";
            this.ttmiDangXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.ttmiDangXuat.Size = new System.Drawing.Size(282, 26);
            this.ttmiDangXuat.Text = "Đăng xuất";
            this.ttmiDangXuat.Click += new System.EventHandler(this.ttmiDangXuat_Click);
            // 
            // chứcNăngToolStripMenuItem
            // 
            this.chứcNăngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmMônHọcToolStripMenuItem,
            this.thêmToolStripMenuItem,
            this.xóaToolStripMenuItem});
            this.chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            this.chứcNăngToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.chứcNăngToolStripMenuItem.Size = new System.Drawing.Size(100, 25);
            this.chứcNăngToolStripMenuItem.Text = "Chức năng";
            // 
            // tìmMônHọcToolStripMenuItem
            // 
            this.tìmMônHọcToolStripMenuItem.Name = "tìmMônHọcToolStripMenuItem";
            this.tìmMônHọcToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.tìmMônHọcToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.tìmMônHọcToolStripMenuItem.Text = "Tìm môn học";
            this.tìmMônHọcToolStripMenuItem.Click += new System.EventHandler(this.tìmMônHọcToolStripMenuItem_Click);
            // 
            // thêmToolStripMenuItem
            // 
            this.thêmToolStripMenuItem.Name = "thêmToolStripMenuItem";
            this.thêmToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.thêmToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.thêmToolStripMenuItem.Text = "Thêm vô lớp";
            this.thêmToolStripMenuItem.Click += new System.EventHandler(this.thêmToolStripMenuItem_Click);
            // 
            // xóaToolStripMenuItem
            // 
            this.xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
            this.xóaToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.xóaToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.xóaToolStripMenuItem.Text = "Xóa khỏi lớp";
            this.xóaToolStripMenuItem.Click += new System.EventHandler(this.xóaToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Location = new System.Drawing.Point(12, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(960, 535);
            this.panel1.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.btThoat);
            this.panel5.Controls.Add(this.btXoaSV_MH);
            this.panel5.Controls.Add(this.btThemSV_MH);
            this.panel5.Location = new System.Drawing.Point(829, 107);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(128, 425);
            this.panel5.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::_1751012086_TrinhHoangYen.Properties.Resources.Alpha_icon;
            this.pictureBox1.Location = new System.Drawing.Point(4, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // btThoat
            // 
            this.btThoat.BackColor = System.Drawing.Color.White;
            this.btThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btThoat.FlatAppearance.BorderSize = 0;
            this.btThoat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btThoat.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThoat.ForeColor = System.Drawing.Color.Black;
            this.btThoat.Location = new System.Drawing.Point(9, 307);
            this.btThoat.Name = "btThoat";
            this.btThoat.Size = new System.Drawing.Size(110, 40);
            this.btThoat.TabIndex = 12;
            this.btThoat.Text = "Thoát";
            this.btThoat.UseVisualStyleBackColor = false;
            // 
            // btXoaSV_MH
            // 
            this.btXoaSV_MH.BackColor = System.Drawing.Color.Black;
            this.btXoaSV_MH.FlatAppearance.BorderSize = 0;
            this.btXoaSV_MH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btXoaSV_MH.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaSV_MH.ForeColor = System.Drawing.Color.White;
            this.btXoaSV_MH.Location = new System.Drawing.Point(9, 251);
            this.btXoaSV_MH.Name = "btXoaSV_MH";
            this.btXoaSV_MH.Size = new System.Drawing.Size(110, 40);
            this.btXoaSV_MH.TabIndex = 11;
            this.btXoaSV_MH.Text = "Xóa khỏi lớp";
            this.btXoaSV_MH.UseVisualStyleBackColor = false;
            this.btXoaSV_MH.Click += new System.EventHandler(this.btXoaSV_MH_Click);
            // 
            // btThemSV_MH
            // 
            this.btThemSV_MH.BackColor = System.Drawing.Color.White;
            this.btThemSV_MH.FlatAppearance.BorderSize = 0;
            this.btThemSV_MH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btThemSV_MH.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemSV_MH.ForeColor = System.Drawing.Color.Black;
            this.btThemSV_MH.Location = new System.Drawing.Point(9, 195);
            this.btThemSV_MH.Name = "btThemSV_MH";
            this.btThemSV_MH.Size = new System.Drawing.Size(110, 40);
            this.btThemSV_MH.TabIndex = 10;
            this.btThemSV_MH.Text = "Thêm vô lớp";
            this.btThemSV_MH.UseVisualStyleBackColor = false;
            this.btThemSV_MH.Click += new System.EventHandler(this.btThemSV_MH_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.txtTimSV);
            this.panel2.Controls.Add(this.btTimSV);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtSdtSV);
            this.panel2.Controls.Add(this.txtHoTenSV);
            this.panel2.Controls.Add(this.txtLopSV);
            this.panel2.Controls.Add(this.txtGioiTinhSV);
            this.panel2.Location = new System.Drawing.Point(429, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(528, 100);
            this.panel2.TabIndex = 0;
            // 
            // txtTimSV
            // 
            this.txtTimSV.Location = new System.Drawing.Point(71, 14);
            this.txtTimSV.Name = "txtTimSV";
            this.txtTimSV.Size = new System.Drawing.Size(116, 26);
            this.txtTimSV.TabIndex = 19;
            // 
            // btTimSV
            // 
            this.btTimSV.BackColor = System.Drawing.Color.Black;
            this.btTimSV.FlatAppearance.BorderSize = 0;
            this.btTimSV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btTimSV.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimSV.ForeColor = System.Drawing.Color.White;
            this.btTimSV.Location = new System.Drawing.Point(33, 46);
            this.btTimSV.Name = "btTimSV";
            this.btTimSV.Size = new System.Drawing.Size(110, 40);
            this.btTimSV.TabIndex = 16;
            this.btTimSV.Text = "Tìm";
            this.btTimSV.UseVisualStyleBackColor = false;
            this.btTimSV.Click += new System.EventHandler(this.btTimSV_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(239, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 18);
            this.label5.TabIndex = 18;
            this.label5.Text = "Số điện thoại:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(418, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 18);
            this.label4.TabIndex = 17;
            this.label4.Text = "Lớp:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 18);
            this.label1.TabIndex = 14;
            this.label1.Text = "MSSV:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(273, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "Giới tính:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(236, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 18);
            this.label2.TabIndex = 15;
            this.label2.Text = "Tên sinh viên:";
            // 
            // txtSdtSV
            // 
            this.txtSdtSV.Enabled = false;
            this.txtSdtSV.Location = new System.Drawing.Point(342, 68);
            this.txtSdtSV.Name = "txtSdtSV";
            this.txtSdtSV.ReadOnly = true;
            this.txtSdtSV.Size = new System.Drawing.Size(178, 26);
            this.txtSdtSV.TabIndex = 15;
            // 
            // txtHoTenSV
            // 
            this.txtHoTenSV.Enabled = false;
            this.txtHoTenSV.Location = new System.Drawing.Point(342, 6);
            this.txtHoTenSV.Name = "txtHoTenSV";
            this.txtHoTenSV.ReadOnly = true;
            this.txtHoTenSV.Size = new System.Drawing.Size(178, 26);
            this.txtHoTenSV.TabIndex = 14;
            // 
            // txtLopSV
            // 
            this.txtLopSV.Enabled = false;
            this.txtLopSV.Location = new System.Drawing.Point(460, 36);
            this.txtLopSV.Name = "txtLopSV";
            this.txtLopSV.ReadOnly = true;
            this.txtLopSV.Size = new System.Drawing.Size(60, 26);
            this.txtLopSV.TabIndex = 13;
            // 
            // txtGioiTinhSV
            // 
            this.txtGioiTinhSV.Enabled = false;
            this.txtGioiTinhSV.Location = new System.Drawing.Point(342, 36);
            this.txtGioiTinhSV.Name = "txtGioiTinhSV";
            this.txtGioiTinhSV.ReadOnly = true;
            this.txtGioiTinhSV.Size = new System.Drawing.Size(60, 26);
            this.txtGioiTinhSV.TabIndex = 12;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.lvSinhVien);
            this.panel4.Location = new System.Drawing.Point(429, 107);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(398, 428);
            this.panel4.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.label10);
            this.panel7.Controls.Add(this.txtSiSo);
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.txtCBGV);
            this.panel7.Controls.Add(this.txtTenMH);
            this.panel7.Controls.Add(this.txtSoTC);
            this.panel7.Location = new System.Drawing.Point(6, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(389, 138);
            this.panel7.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(79, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(228, 24);
            this.label10.TabIndex = 20;
            this.label10.Text = "THÔNG TIN MÔN HỌC";
            // 
            // txtSiSo
            // 
            this.txtSiSo.Enabled = false;
            this.txtSiSo.Location = new System.Drawing.Point(299, 66);
            this.txtSiSo.Name = "txtSiSo";
            this.txtSiSo.ReadOnly = true;
            this.txtSiSo.Size = new System.Drawing.Size(65, 26);
            this.txtSiSo.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(72, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 18);
            this.label6.TabIndex = 18;
            this.label6.Text = "CBGV:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(199, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 18);
            this.label7.TabIndex = 17;
            this.label7.Text = "Sĩ số hiện tại:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(51, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 18);
            this.label8.TabIndex = 16;
            this.label8.Text = "Số tín chỉ:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 18);
            this.label9.TabIndex = 15;
            this.label9.Text = "Tên môn học:";
            // 
            // txtCBGV
            // 
            this.txtCBGV.Enabled = false;
            this.txtCBGV.Location = new System.Drawing.Point(128, 98);
            this.txtCBGV.Name = "txtCBGV";
            this.txtCBGV.ReadOnly = true;
            this.txtCBGV.Size = new System.Drawing.Size(236, 26);
            this.txtCBGV.TabIndex = 15;
            // 
            // txtTenMH
            // 
            this.txtTenMH.Enabled = false;
            this.txtTenMH.Location = new System.Drawing.Point(128, 34);
            this.txtTenMH.Name = "txtTenMH";
            this.txtTenMH.ReadOnly = true;
            this.txtTenMH.Size = new System.Drawing.Size(236, 26);
            this.txtTenMH.TabIndex = 14;
            // 
            // txtSoTC
            // 
            this.txtSoTC.Enabled = false;
            this.txtSoTC.Location = new System.Drawing.Point(128, 66);
            this.txtSoTC.Name = "txtSoTC";
            this.txtSoTC.ReadOnly = true;
            this.txtSoTC.Size = new System.Drawing.Size(65, 26);
            this.txtSoTC.TabIndex = 12;
            // 
            // lvSinhVien
            // 
            this.lvSinhVien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader3,
            this.columnHeader2});
            this.lvSinhVien.FullRowSelect = true;
            this.lvSinhVien.GridLines = true;
            this.lvSinhVien.Location = new System.Drawing.Point(6, 149);
            this.lvSinhVien.Name = "lvSinhVien";
            this.lvSinhVien.Size = new System.Drawing.Size(389, 275);
            this.lvSinhVien.TabIndex = 22;
            this.lvSinhVien.UseCompatibleStateImageBehavior = false;
            this.lvSinhVien.View = System.Windows.Forms.View.Details;
            this.lvSinhVien.SelectedIndexChanged += new System.EventHandler(this.lvSinhVien_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "MSSV";
            this.columnHeader1.Width = 90;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Họ tên";
            this.columnHeader3.Width = 183;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Ngày đăng ký";
            this.columnHeader2.Width = 107;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.Controls.Add(this.lvMonHoc);
            this.panel10.Controls.Add(this.panel3);
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(426, 529);
            this.panel10.TabIndex = 5;
            // 
            // lvMonHoc
            // 
            this.lvMonHoc.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clMa,
            this.clTen,
            this.clNgay,
            this.clTT});
            this.lvMonHoc.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvMonHoc.FullRowSelect = true;
            this.lvMonHoc.GridLines = true;
            this.lvMonHoc.Location = new System.Drawing.Point(3, 104);
            this.lvMonHoc.Name = "lvMonHoc";
            this.lvMonHoc.Size = new System.Drawing.Size(423, 422);
            this.lvMonHoc.TabIndex = 1;
            this.lvMonHoc.UseCompatibleStateImageBehavior = false;
            this.lvMonHoc.View = System.Windows.Forms.View.Details;
            this.lvMonHoc.SelectedIndexChanged += new System.EventHandler(this.lvMonHoc_SelectedIndexChanged);
            // 
            // clMa
            // 
            this.clMa.Text = "Mã môn học";
            this.clMa.Width = 100;
            // 
            // clTen
            // 
            this.clTen.Text = "Tên môn học";
            this.clTen.Width = 200;
            // 
            // clNgay
            // 
            this.clNgay.Text = "Ngày kết thúc";
            this.clNgay.Width = 100;
            // 
            // clTT
            // 
            this.clTT.Text = "Trạng thái";
            this.clTT.Width = 100;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.cbTimKhoa);
            this.panel3.Controls.Add(this.btTimMH);
            this.panel3.Controls.Add(this.txtTimMH);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(423, 100);
            this.panel3.TabIndex = 1;
            // 
            // cbTimKhoa
            // 
            this.cbTimKhoa.FormattingEnabled = true;
            this.cbTimKhoa.Location = new System.Drawing.Point(40, 18);
            this.cbTimKhoa.Name = "cbTimKhoa";
            this.cbTimKhoa.Size = new System.Drawing.Size(210, 26);
            this.cbTimKhoa.TabIndex = 9;
            // 
            // btTimMH
            // 
            this.btTimMH.BackColor = System.Drawing.Color.White;
            this.btTimMH.FlatAppearance.BorderSize = 0;
            this.btTimMH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btTimMH.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimMH.ForeColor = System.Drawing.Color.Black;
            this.btTimMH.Location = new System.Drawing.Point(273, 30);
            this.btTimMH.Name = "btTimMH";
            this.btTimMH.Size = new System.Drawing.Size(110, 40);
            this.btTimMH.TabIndex = 8;
            this.btTimMH.Text = "Tìm môn học";
            this.btTimMH.UseVisualStyleBackColor = false;
            this.btTimMH.Click += new System.EventHandler(this.btTimMH_Click);
            // 
            // txtTimMH
            // 
            this.txtTimMH.Location = new System.Drawing.Point(40, 56);
            this.txtTimMH.Name = "txtTimMH";
            this.txtTimMH.Size = new System.Drawing.Size(210, 26);
            this.txtTimMH.TabIndex = 0;
            // 
            // fQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CancelButton = this.btThoat;
            this.ClientSize = new System.Drawing.Size(984, 581);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fQuanLy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần mềm quản lớp học";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ttmiDanhMuc;
        private System.Windows.Forms.ToolStripMenuItem ttmiTaiKhoan;
        private System.Windows.Forms.ToolStripMenuItem ttmiThongTinTaiKhoan;
        private System.Windows.Forms.ToolStripMenuItem ttmiDangXuat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtTimMH;
        private System.Windows.Forms.Button btTimMH;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtGioiTinhSV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSdtSV;
        private System.Windows.Forms.TextBox txtHoTenSV;
        private System.Windows.Forms.TextBox txtLopSV;
        private System.Windows.Forms.ListView lvMonHoc;
        private System.Windows.Forms.ColumnHeader clMa;
        private System.Windows.Forms.ColumnHeader clTen;
        private System.Windows.Forms.ColumnHeader clNgay;
        private System.Windows.Forms.ColumnHeader clTT;
        private System.Windows.Forms.Button btTimSV;
        private System.Windows.Forms.ComboBox cbTimKhoa;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSiSo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCBGV;
        private System.Windows.Forms.TextBox txtTenMH;
        private System.Windows.Forms.TextBox txtSoTC;
        private System.Windows.Forms.ListView lvSinhVien;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btThoat;
        private System.Windows.Forms.Button btXoaSV_MH;
        private System.Windows.Forms.Button btThemSV_MH;
        private System.Windows.Forms.TextBox txtTimSV;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem;
    }
}